
  # Add Firebase Login and Alerts

  This is a code bundle for Add Firebase Login and Alerts. The original project is available at https://www.figma.com/design/vQCG16YjxANv0M2uFe2fHD/Add-Firebase-Login-and-Alerts.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  